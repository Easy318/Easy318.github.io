import random
lines = []


for i in range(5000):
	a = random.randint(1, 100)
	b = random.randint(1, 100)
	c = a + b
	lines.append(str(a) + '+' + str(b) + '=' + str(c) + '\n')

for i in range(5000):
	a = random.randint(100, 1000)
	b = random.randint(10, 100)
	c = a + b
	lines.append(str(a) + '+' + str(b) + '=' + str(c) + '\n')



for i in range(2500):
	a = random.randint(1, 100)
	b = random.randint(1, 10)
	if a >= b:
		d = a - b
		lines.append(str(a) + '-' + str(b) + '=' + str(d) + '\n')
	else:
		d = b - a
		lines.append(str(b) + '-' + str(a) + '=' + str(d) + '\n')

for i in range(2500):
	a = random.randint(11, 100)
	b = random.randint(11, 100)
	if a >= b:
		d = a - b
		lines.append(str(a) + '-' + str(b) + '=' + str(d) + '\n')
	else:
		d = b - a
		lines.append(str(b) + '-' + str(a) + '=' + str(d) + '\n')

for i in range(2500):
	a = random.randint(11, 1000)
	b = random.randint(11, 100)
	if a >= b:
		d = a - b
		lines.append(str(a) + '-' + str(b) + '=' + str(d) + '\n')
	else:
		d = b - a
		lines.append(str(b) + '-' + str(a) + '=' + str(d) + '\n')

for i in range(2500):
	a = random.randint(100, 1000)
	b = random.randint(100, 1000)
	if a >= b:
		d = a - b
		lines.append(str(a) + '-' + str(b) + '=' + str(d) + '\n')
	else:
		d = b - a
		lines.append(str(b) + '-' + str(a) + '=' + str(d) + '\n')
        

for i in range(5000):
	a = random.randint(1, 99)
	b = random.randint(1, 99)
	e = a * b
	lines.append(str(a) + '*' + str(b) + '=' + str(e) + '\n')

for i in range(5000):
	a = random.randint(100, 1000)
	b = random.randint(1, 100)
	e = a * b
	lines.append(str(a) + '*' + str(b) + '=' + str(e) + '\n')


for i in range(100):
	a = random.randint(1,10)
	b = random.randint(1,10)
	f = a * b
	lines.append(str(f) + "/" + str(b) + "=" + str(a) + "\n")

for i in range(5000):
	a = random.randint(1,1000)
	b = random.randint(1,10)
	f = a * b
	lines.append(str(f) + "/" + str(b) + "=" + str(a) + "\n")

for i in range(5000):
	a = random.randint(1,1000)
	b = random.randint(11,99)
	f = a * b
	lines.append(str(f) + "/" + str(b) + "=" + str(a) + "\n")

f = open('all.txt', 'w')
f.writelines(lines)
f.close()