#-*-coding:utf-8 -*-
#1 judge + and =
def count(str_t, char_t):
	number = 0
	for item in str_t:
		if item == char_t:
			number += 1
	return number

def judge(str_line):
	try:
		[temp, answer] = str_line.strip().split('=')
	except:
		return False
	if '+' in temp:
		try:
			[item1, item2] = temp.split('+')
		except:
			return False
		try:
			if float(item1) + float(item2) == float(answer):
				return True
		except:
			return False
		else:
			return False

	elif '-' in temp:
		try:
			[item1, item2] = temp.split('-')
		except:
			return False
		if float(item1) - float(item2) == float(answer):
			return True
		else:
			return False

	elif '×' in temp:
		try:
			[item1, item2] = temp.split('×')
		except:
			return False
		if float(item1) * float(item2) == float(answer):
			return True
		else:
			return False

	elif '÷' in temp:
		try:
			[item1, item2] = temp.split('÷')
		except:
			return False
		if float(item1) / float(item2) == float(answer):
			return True
		else:
			return False
	else:
		return False



f = open("result.txt")
lines = f.readlines()
epoch_index = 0
count_all = 0
count_c1 = 0
count_c2 = 0
for line in lines:
	if line == '\n':
		continue
	count_all += 1

	if 'Thi' in line:
		if not epoch_index == 0:
			accuracy_1 = float(count_c1) / float(count_all)
			accuracy_2 = float(count_c2) / float(count_all)
			print('epoch : ' + str(epoch_index) + " c1: " + str(accuracy_1) + ';   c2 : ' + str(accuracy_2))

		epoch_index += 1
		count_all = 0
		count_c1 = 0
		count_c2 = 0
		continue

	# c1
	if not ((count(line, '+') == 1) and (count(line, '=') == 1)):
		continue
	else:
		count_c1 += 1

	#c2
	if judge(line):
		count_c2 += 1



